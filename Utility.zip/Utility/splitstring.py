def split_date_string(date):
    xdate = date.split('/')
    mm,dd,yyyy = xdate
    return mm, dd, yyyy