import subprocess

subprocess.run("pabot --processes 3 --outputdir C:\\Users\\rn10\\PycharmProjects\\OneMD\\Results C:\\Users\\rn10\\PycharmProjects\\OneMD\\Tests\\*.robot", shell=True, stdout=subprocess.PIPE)